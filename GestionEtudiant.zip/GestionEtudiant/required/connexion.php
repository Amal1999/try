<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
 $db = new PDO("mysql:host=$servername;dbname=istic", $username, $password);
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  echo "connexion échouée: " . $e->getMessage();
}
?> 