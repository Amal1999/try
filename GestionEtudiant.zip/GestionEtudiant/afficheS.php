<?php
include_once'required/connexion.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
    td
    {
       border:1px solid black;
    }
    
    
    </style>
</head>
<body>





<?php


$query = $db->query("select * from etudiant;");
$afficher="<table '>";
$i=0;
while($reponse= $query->fetch())
{
    $i++;
    $afficher.="
<tr><td >Etudiant numéro $i </td>
<td><table>
<tr><td>CIN</td><td>".$reponse['CIN_et']."</td></tr>
<tr><td>Nom de l'étudiant </td><td colspan='3'>".$reponse['NOM_et']."</td></tr>
<tr><td>Prénom de l'étudiant </td><td colspan='3'>".$reponse['PRENOM_et']."</td></tr>
<tr><td>Email de l'étudiant </td><td colspan='3'>".$reponse['EMAIL_et']."</td></tr>
</table></td><tr>";

}
$afficher.="</table>";
echo $afficher;

?>
</body>
</html>

