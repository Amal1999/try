<?php
include_once '../required/connexion.php'
?>
<?php
if(!isset($_GET["submit"]))
{
    $request=$db->query("select * from etudiant;");
    $response=$request->fetchAll();
    echo json_encode($response);
}
else
{
    $id=$_GET['cin'];
 $db->exec("delete from etudiant where CIN_et='".$id ."'");

}




?>