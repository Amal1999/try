
<?php
include_once'required/connexion.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
    td
    {
       border:1px solid black;
    }
    
    
    </style>
</head>
<body>


<?php


$query = $db->query("select * from classe;");

$afficher="<table>";
$i=0;
while($reponse= $query->fetch())
{
    
    $i++;
    $afficher.="
<tr><td >La classe numéro $i </td>
<td><table>
<tr><td>l'id de la classe</td><td>".$reponse['ID_classe']."</td></tr>
<tr><td>Nom de la classe </td><td colspan='3'>".$reponse['NOM_classe']."</td></tr>
<tr><td>Salle </td><td colspan='3'>".$reponse['SALLE_classe']."</td></tr>
</table></td><tr>";

}
$afficher.="</table>";
echo $afficher;

?>
</body>