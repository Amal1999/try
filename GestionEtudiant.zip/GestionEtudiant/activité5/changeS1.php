<?php
include_once '../required/connexion.php'
?>

<?php
if(!isset($_GET["submit"]))
{
    $request=$db->query("select * from etudiant;");
    $response=$request->fetchAll();
    echo json_encode($response);
}
else
{
    $request=$db->query("select * from etudiant where CIN_et=".$_GET['cin']." ;");
    $response=$request->fetchAll();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout d'étudiant</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>

    <div class="container">
    <form action="changeS2.php" method="GET" enctype="multipart/form-data" >
     
        <div class="form-row  ">
            <div class="form-group col-3  ">
            <label for="nom">Nom: </label> <input type="text"class="form-control" value= '<?php echo $response[0]["NOM_et"]?>' required name="nom" id="nom">
            </div>
            <div class="form-group col-3">
              <label for="prenom">Prénom: </label> <input value= '<?php echo $response[0]["PRENOM_et"]?>'type="text"class="form-control"required name="prenom" id="prenom">
            </div>
          </div>
        
          <input type= "hidden" value="<?php echo $_GET['cin'];?>" name="ancienne_cin">
          <div class="form-row">
            <div class="form-group col-3">
              <label for="cin">CIN: </label><input type="text" pattern="[0-9]{8}" value= '<?php echo $response[0]["CIN_et"]?>' required class="form-control" name="cin" id="cin">
            </div>
            <div class="form-group col-3">
              <label for="email">Email: </label> <input type="email" value= '<?php echo $response[0]["EMAIL_et"]?>' class="form-control" required name="email" id="email">
            </div>
          </div>


          <div class="row">
              <div class="col-3 offset-3">
            <input type="submit" name="modifier" value="modifier"> 
            </div>
        </div>

    </form>
</div>



</body>
</html>
<?php
}
?>