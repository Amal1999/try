<?php
include_once '../required/connexion.php'
?>
<?php 

$email = $_GET["email"];

$cin = $_GET["cin"];

$nom=$_GET["nom"];

$prenom=$_GET["prenom"];

$anc=$_GET['ancienne_cin'];

$req=$db->exec("update etudiant set NOM_et='".$nom."',PRENOM_et='".$prenom."',CIN_et='".$cin."',EMAIL_et='".$email."' where CIN_et='".$anc."'");

?>