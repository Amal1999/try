<?php
include_once '../required/connexion.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



    <?php
    if(isset($_GET['submit']))
    {
        $cin=$_GET['cin'];
        $req=$db->query("select * from etudiant where CIN_et=$cin");
        $rep=$req->fetchAll();
        ?>
        <div class="row">
        <div class="col-3">
            <img src="../activité4/image/<?echo $cin?>.jpg">
        </div>
        <div class="row">
        <?php
          for($i=0;$i<count($rep[0])/2;$i++)
          {
              ?>
              <div class="col-5">
                  <?php echo $rep[0][$i];?>
              </div>
              <?php
          }
    }
    else
        {
            ?>
            
    <form action='#'>


<div class="row">
<div class="col-3"><label for="cin">CIN :</label></div>
<div class="col-5"><input type="text" id="cin" name="cin" pattern="[0-9]{8}" placeholder='Exemple:12345678'></div>
</div>
<div class="row">
<input type="submit" value="rechercher" name="submit">
</div>

</form>

            
            
            <?php
        }
        
        ?>
           
        </div>
        </div>
        
        <?php

    
    ?>


</body>
</html>