<?php
include_once '../required/connexion.php'
?>
<?php


    $request=$db->query("select * from classe;");
    $response=$request->fetchAll();
    echo json_encode($response);

   


?>