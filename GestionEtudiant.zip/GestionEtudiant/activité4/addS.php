<?php
include_once '../required/connexion.php'
?>

<?php


    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $cin = $_POST['cin'];
    $email = $_POST['email'];
    $groupe = $_POST['groupe'];
    
    $requete=$db->prepare("insert into etudiant(CIN_et,NOM_et,PRENOM_et,EMAIL_et) values(?,?,?,?);");
    $executer= $requete->execute([$cin,$prenom,$nom,$email]);
    
    $requete=$db->prepare("insert into ETUDIANT_CLASSE(CIN_et,ID_classe) values(?,?);");
    $executer= $requete->execute([$cin,$groupe]);
    
     move_uploaded_file($_FILES["tof1"]["tmp_name"],"image/$cin.jpg");







?>